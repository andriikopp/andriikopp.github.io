class User:
    def __init__(self, id, firstname, lastname, birthdate, email):
        self.id = id
        self.firstname = firstname
        self.lastname = lastname
        self.birthdate = birthdate
        self.email = email


    def __repr__(self):
        return '{}, {}, {}, {}, {}'.format(self.id, self.firstname, self.lastname, self.birthdate, self.email)

