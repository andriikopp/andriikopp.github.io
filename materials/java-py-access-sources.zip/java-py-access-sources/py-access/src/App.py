from src.entity.User import User

from src.dao.UserDAO import UserDAO

class App:
    def __init__(self):
        user_dao = UserDAO()

        print(user_dao.read())
        print('--------------------------------------------')

        new_user = User('4', 'John', 'Smith', '4/11/1991', 'smith@mail.com')

        user_dao.create(new_user)

        print(user_dao.read())
        print('--------------------------------------------')

        new_user.lastname = 'Doe'

        user_dao.update(new_user)

        print(user_dao.read())
        print('--------------------------------------------')

        user_dao.delete(new_user)

        print(user_dao.read())


if __name__ == '__main__':
    app = App()

