from src.db.DbUtil import DbUtil

from src.entity.User import User

class UserDAO:
    def __init__(self):
        self.conn = DbUtil.conn

    def create(self, user):
        cursor = self.conn.cursor()
        cursor.execute('insert into user (user_id, user_first_name, user_last_name, user_birthdate, user_email) ' +
                       'values (?, ?, ?, ?, ?)',
                       user.id, user.firstname, user.lastname, user.birthdate, user.email)
        self.conn.commit()


    def read(self):
        users = []

        cursor = self.conn.cursor()
        cursor.execute('select * from user')

        for row in cursor.fetchall():
            user = User(row[0], row[1], row[2], row[3], row[4])
            users.append(user)

        return users


    def update(self, user):
        cursor = self.conn.cursor()
        cursor.execute('update user set user_first_name = ?, user_last_name = ?, user_birthdate = ?, ' +
                       'user_email = ? where user_id = ?',
                       user.firstname, user.lastname, user.birthdate, user.email, user.id)
        self.conn.commit()


    def delete(self, user):
        cursor = self.conn.cursor()
        cursor.execute('delete from user where user_id = ?', user.id)
        self.conn.commit()

