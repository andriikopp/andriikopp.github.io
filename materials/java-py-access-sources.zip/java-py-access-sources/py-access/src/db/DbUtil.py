import pyodbc

class DbUtil:
    conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};'
                          r'DBQ=D:\GitHub\db-design\pyodbc\pyodbc-demo.accdb;')

