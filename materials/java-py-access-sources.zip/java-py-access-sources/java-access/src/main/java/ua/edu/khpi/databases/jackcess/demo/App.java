package ua.edu.khpi.databases.jackcess.demo;

import java.util.Date;

import ua.edu.khpi.databases.jackcess.demo.bean.User;
import ua.edu.khpi.databases.jackcess.demo.dao.UserDAO;

public class App {
	public static void main(String[] args) {
		UserDAO userDAO = new UserDAO();
		
		for (User user : userDAO.read()) {
			System.out.println(user);
		}
		
		System.out.println("---------------------------------------");
		
		User newUser = new User();
		
		newUser.setFirstName("John");
		newUser.setLastName("Smith");
		newUser.setBirthDate(new Date());
		newUser.setEmail("smith@mail.com");
		
		userDAO.create(newUser);
		
		for (User user : userDAO.read()) {
			System.out.println(user);
		}
		
		System.out.println("---------------------------------------");
		
		newUser.setLastName("Doe");
		
		userDAO.update(newUser);
		
		for (User user : userDAO.read()) {
			System.out.println(user);
		}
		
		System.out.println("---------------------------------------");
		
		userDAO.delete(newUser);
		
		for (User user : userDAO.read()) {
			System.out.println(user);
		}
	}
}
