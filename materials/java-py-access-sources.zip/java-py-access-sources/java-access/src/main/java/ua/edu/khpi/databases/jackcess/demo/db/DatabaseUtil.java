package ua.edu.khpi.databases.jackcess.demo.db;

import java.io.File;
import java.io.IOException;

import com.healthmarketscience.jackcess.Database;
import com.healthmarketscience.jackcess.DatabaseBuilder;

public class DatabaseUtil {
	private static final String DB_FILE_NAME = "jackcess-demo.accdb";

	public static Database getDatabase() {
		try {
			return DatabaseBuilder.open(new File(DB_FILE_NAME));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
