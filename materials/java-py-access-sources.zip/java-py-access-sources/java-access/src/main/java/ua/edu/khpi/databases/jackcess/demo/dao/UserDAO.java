package ua.edu.khpi.databases.jackcess.demo.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.healthmarketscience.jackcess.Row;
import com.healthmarketscience.jackcess.Table;

import ua.edu.khpi.databases.jackcess.demo.bean.User;
import ua.edu.khpi.databases.jackcess.demo.db.DatabaseUtil;

public class UserDAO {
	private static final String DB_TABLE_NAME = "user";

	private static final String USER_ID_COL = "user_id";
	private static final String USER_FIRSTNAME_COL = "user_first_name";
	private static final String USER_LASTNAME_COL = "user_last_name";
	private static final String USER_BIRTHDATE_COL = "user_birthdate";
	private static final String USER_EMAIL_COL = "user_email";

	private Table table;

	public UserDAO() {
		try {
			this.table = DatabaseUtil.getDatabase().getTable(DB_TABLE_NAME);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public void create(User user) {
		user.setId(UUID.randomUUID().toString());

		try {
			Map<String, Object> map = new HashMap<String, Object>();

			map.put(USER_ID_COL, user.getId());
			map.put(USER_FIRSTNAME_COL, user.getFirstName());
			map.put(USER_LASTNAME_COL, user.getLastName());
			map.put(USER_BIRTHDATE_COL, user.getBirthDate());
			map.put(USER_EMAIL_COL, user.getEmail());

			table.addRowFromMap(map);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public List<User> read() {
		List<User> users = new ArrayList<User>();

		for (Row row : table) {
			User user = new User();

			user.setId(row.getString(USER_ID_COL));
			user.setFirstName(row.getString(USER_FIRSTNAME_COL));
			user.setLastName(row.getString(USER_LASTNAME_COL));
			user.setBirthDate(row.getDate(USER_BIRTHDATE_COL));
			user.setEmail(row.getString(USER_EMAIL_COL));

			users.add(user);
		}

		return users;
	}

	public void update(User user) {
		try {
			for (Row row : table) {
				if (row.getString(USER_ID_COL).equals(user.getId())) {
					row.put(USER_FIRSTNAME_COL, user.getFirstName());
					row.put(USER_LASTNAME_COL, user.getLastName());
					row.put(USER_BIRTHDATE_COL, user.getBirthDate());
					row.put(USER_EMAIL_COL, user.getEmail());

					table.updateRow(row);

					break;
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public void delete(User user) {
		try {
			for (Row row : table) {
				if (row.getString(USER_ID_COL).equals(user.getId())) {
					table.deleteRow(row);

					break;
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
