package ua.edu.khpi.databases.jsondb.demo.dao;

import java.util.List;

import io.jsondb.JsonDBTemplate;
import ua.edu.khpi.databases.jsondb.demo.entity.Product;

public class ProductDAO {
	private JsonDBTemplate jsonDbTemplate;

	public ProductDAO() {
		String dbFilesLocation = "productsdb/";
		String scanPackage = "ua.edu.khpi.databases.jsondb.demo.entity";

		this.jsonDbTemplate = new JsonDBTemplate(dbFilesLocation, scanPackage);

		if (!this.jsonDbTemplate.collectionExists(Product.class)) {
			this.jsonDbTemplate.createCollection(Product.class);
		}
	}

	public void create(Product product) {
		this.jsonDbTemplate.insert(product);
	}

	public List<Product> read() {
		return this.jsonDbTemplate.findAll(Product.class);
	}

	public void update(Product product) {
		this.jsonDbTemplate.upsert(product);
	}

	public void delete(Product product) {
		this.jsonDbTemplate.remove(product, Product.class);
	}
}
