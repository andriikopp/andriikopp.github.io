package ua.edu.khpi.databases.jsondb.demo;

import ua.edu.khpi.databases.jsondb.demo.dao.ProductDAO;
import ua.edu.khpi.databases.jsondb.demo.entity.Product;

public class App {
	
	public static void main(String[] args) {
		Product product = new Product();
		product.setId("P0001");
		product.setName("Samsung A30 4/64 Black");
		product.setCategory("Smartphones");
		product.setPrice(6500);
		
		ProductDAO productDAO = new ProductDAO();
		
		productDAO.create(product);
		
		System.out.println(productDAO.read());
		
		product.setName("Samsung A30 4/64 Blue");
		
		productDAO.update(product);
		
		System.out.println(productDAO.read());

		productDAO.delete(product);
		
		System.out.println(productDAO.read());
	}
}
