package ua.edu.khpi.databases.jsondb.demo.entity;

import io.jsondb.annotation.Document;
import io.jsondb.annotation.Id;

@Document(collection = "products", schemaVersion = "1.0")
public class Product {
	@Id
	private String id;
	private String name;
	private String category;
	private long price;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", category=" + category + ", price=" + price + "]";
	}
}
